
//import './assets/css/bootstrap.min.css';
//import './assets/dash-css/all.css';


function promotions() {
    return (
        <div className="page">
        <div className="sidebar">
         <div className="sidebar__head">
            <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
            <button className="sidebar__toggle">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                  <path d="M22 12H3" stroke="#11142d"></path>
                  <g stroke="#808191">
                     <path d="M22 4H13"></path>
                     <path opacity=".301" d="M22 20H13"></path>
                  </g>
                  <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
               </svg>
            </button>
            <button className="sidebar__close">
               <svg className="icon icon-close">
                 
               </svg>
            </button>
         </div>
      
         <div className="sidebar__body">
            <nav className="sidebar__nav">
            <a className="sidebar__item" href="/dashboard">
               <div className="sidebar__icon">
                  <svg className="icon icon-home">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Dashboard</div>
            </a>
            
      
            <a className="sidebar__item" href="/statistics">
          
               <div className="sidebar__icon">
                  <svg className="icon icon-chart">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Statistics</div>
            
            </a>
      
            <a className="sidebar__item" href="/pairs">
               <div className="sidebar__icon">
                  <svg className="icon icon-document">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Pairs</div>
            </a>
            <a className="sidebar__item" href="/swap">
               <div className="sidebar__icon">
                  <svg className="icon icon-wallet">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Swap</div>
            </a>
            <a className="sidebar__item" href="/staking">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Staking</div>
            </a>
            <a className="sidebar__item" href="/promotions">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text active">Promotions</div>
            </a>
            <a className="sidebar__item" href="/presale">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Apply For Presale</div>
            </a>
            <a className="sidebar__item" href="/activities"></a>
            </nav>
         </div>
      
         <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
        
         </svg><svg className="icon icon-theme-dark">
         
         </svg></span></span></label>
         <a className="sidebar__user" href="sign-in.html">
           <img src={"/assets/img/ava-header.png"} />
           
           </a>
         </div>
      </div>
      
      <div className="page__content">
            <div className="header header_border">
                <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
                <div className="header__group">



                    <button className="wallets__btn btn btn_border create-pol">
                  
                  <span className="btn__text">Connect Wallet</span></button>
                </div>
                <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a><button className="header__toggle"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path d="M22 12H3" stroke="#11142d"></path>
              <g stroke="#808191">
                <path d="M22 4H13"></path>
                <path opacity=".301" d="M22 20H13"></path>
              </g>
              <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
            </svg></button>
            </div>
            <div className="promotions">
                <div className="promotions__wrapper">
                    <div className="promotions__brand h5">Unity Exchange</div>
                    <div className="promotions__title h2">Promotions</div>
                    <div className="promotions__row">
                        <div className="promotions__col">
                            <div className="slider slider_promotions">
                                <div className="slider__container">
                                    <div className="slider__list js-slider">
                                        <div className="slider__item">
                                            <div className="slider__wrap">
                                                <div className="slider__date">Oct 26th - Nov 25th</div>
                                                <div className="slider__title">Bitcoin x TRON Net Deposit Campaign</div>
                                                <div className="slider__info">To celebrate our new multi-chain deposit and withdrawal support for Bitcoin on TRON (BTCTRON), we’re beginning a 30-day net deposit…</div><button className="slider__btn btn btn_white">Earn Crypto</button>
                                            </div>
                                            <div className="slider__preview"><img src="/assets/img/figures-2.png" alt=""/></div>
                                        </div>
                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="promotions__col">
                            <div className="promotions__head">
                                <div className="promotions__category h6">Featured Promotions</div>
                                <div className="dropdown"><button className="dropdown__head"><svg className="icon icon-dots">
                        
                      </svg></button>
                                    <div className="dropdown__body"><a className="dropdown__link selected" href="#">Featured Promotions</a><a className="dropdown__link" href="#">New Promotions</a><a className="dropdown__link" href="#">All Promotions</a><a className="dropdown__link" href="#">Featured Promotions</a></div>
                                </div>
                            </div>
                            <div className="promotions__group promotions__group_row">
                                <a className="promotions__box" href="promotion-detail.html">
                                    <div className="promotions__icon"><img src="/assets/img/promotions-icon-1.png" alt=""/></div>
                                    <div className="promotions__details">
                                        <div className="promotions__date">Oct 26th - Nov 25th</div>
                                        <div className="promotions__info">BTC x TRON Net Deposit Campaign</div>
                                    </div>
                                </a>
                                <a className="promotions__box" href="promotion-detail.html">
                                    <div className="promotions__icon"><img src="/assets/img/promotions-icon-2.png" alt=""/></div>
                                    <div className="promotions__details">
                                        <div className="promotions__date">Oct 26th - Nov 25th</div>
                                        <div className="promotions__info">BTC x TRON Net Deposit Campaign</div>
                                    </div>
                                </a>
                                <a className="promotions__box" href="promotion-detail.html">
                                    <div className="promotions__icon"><img src="/assets/img/promotions-icon-3.png" alt=""/></div>
                                    <div className="promotions__details">
                                        <div className="promotions__date">Oct 26th - Nov 25th</div>
                                        <div className="promotions__info">BTC x TRON Net Deposit Campaign</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div className="promotions__stage h5">Latest Promotions</div>
                    <div className="promotions__list">
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-1.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-green-opacity color-green">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="btn__text">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-2.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-green-opacity color-green">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="btn__text">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-3.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-green-opacity color-green">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="balances__btn">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-4.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-green-opacity color-green">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="btn__text">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-5.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-red-opacity color-red">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="btn__text">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                        <div className="promotions__item">
                            <a className="promotions__preview" href="promotion-detail.html"><img src="/assets/img/promotions-pic-1.jpg" alt=""/></a>
                            <div className="promotions__body">
                                <div className="promotions__date bg-green-opacity color-green">Oct 26th - Nov 25th</div><a className="promotions__info" href="promotion-detail.html">Bitcoin x TRON Net Deposit Campaign</a><button className="promotions__btn btn btn_border"><svg className="icon icon-withdraw">
                      
                    </svg><span className="btn__text">Deposit Bitcoin</span></button>
                            </div>
                        </div>
                    </div>
                    <div className="pagination"><a className="pagination__item active" href="#">1</a><a className="pagination__item" href="#">2</a><a className="pagination__item" href="#">3</a><a className="pagination__item" href="#">4</a><a className="pagination__next" href="#">Next<svg className="icon icon-check">
                  
                </svg></a></div>
                </div>
            </div>
        </div>
      
      </div>
    );
  }
  
  export default promotions;