import './App.css';
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';

function swap() {
    return (
        <div className="page">
        <div className="sidebar">
         <div className="sidebar__head">
            <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
            <button className="sidebar__toggle">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                  <path d="M22 12H3" stroke="#11142d"></path>
                  <g stroke="#808191">
                     <path d="M22 4H13"></path>
                     <path opacity=".301" d="M22 20H13"></path>
                  </g>
                  <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
               </svg>
            </button>
            <button className="sidebar__close">
               <svg className="icon icon-close">
                 
               </svg>
            </button>
         </div>
      
         <div className="sidebar__body">
            <nav className="sidebar__nav">
            <a className="sidebar__item" href="/dashboard">
               <div className="sidebar__icon">
                  <svg className="icon icon-home">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Dashboard</div>
            </a>
            
      
            <a className="sidebar__item" href="/statistics">
          
               <div className="sidebar__icon">
                  <svg className="icon icon-chart">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Statistics</div>
            
            </a>
      
            <a className="sidebar__item" href="/pairs">
               <div className="sidebar__icon">
                  <svg className="icon icon-document">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Pairs</div>
            </a>
            <a className="sidebar__item" href="/swap">
               <div className="sidebar__icon">
                  <svg className="icon icon-wallet">
                     
                  </svg>
               </div>
               <div className="sidebar__text active">Swap</div>
            </a>
            <a className="sidebar__item" href="/staking">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Staking</div>
            </a>
            <a className="sidebar__item" href="/promotions">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Promotions</div>
            </a>
            <a className="sidebar__item" href="/presale">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Apply For Presale</div>
            </a>
            <a className="sidebar__item" href="/activities"></a>
            </nav>
         </div>
      
         <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
        
         </svg><svg className="icon icon-theme-dark">
         
         </svg></span></span></label>
         <a className="sidebar__user" href="sign-in.html">
           <img src={"/assets/img/ava-header.png"} />
           
           </a>
         </div>
      </div>
      
      <div className="page__content">
            <div className="header header_border">
                <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
                <div className="header__group">



                    <button className="wallets__btn btn btn_border create-pol">
                  
                  <span className="btn__text">Connect Wallet</span></button>
                </div>
                <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a><button className="header__toggle"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path d="M22 12H3" stroke="#11142d"></path>
              <g stroke="#808191">
                <path d="M22 4H13"></path>
                <path opacity=".301" d="M22 20H13"></path>
              </g>
              <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
            </svg></button>
            </div>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">

                        <div className="swap-form-holder">
                            <div className="settings"><img src="/assets/img/settings.jpg" alt=""/></div>
                            <div className="tabs-holder">
                                <ul className="tabs-links">
                                    <li className="active"><a href="javascript:void(null);" className="">Swap</a></li>
                                    <li className=""><a href="javascript:void(null);" className="">Liquidity</a></li>
                                </ul>
                                <ul className="tabs-content-holder">
                                    <li className="active">
                                        <div className="options-form-holder">
                                            <div className="options-row">
                                                <div className="options-label">From</div>
                                                <div className="option-value-placeholder">placeholder</div>
                                                <div className="select-holder">
                                                    <select className="vodiapicker">
                                <option value="en" className="test" data-thumbnail="/assets/img/logo/ethereum.png">ETH</option>
                                <option value="au" data-thumbnail="/assets/img/logo/ethereum.png">USDT</option>
                                <option value="uk" data-thumbnail="/assets/img/logo/bitcoin.png">BTC</option>
                                <option value="cn" data-thumbnail="/assets/img/logo/logo-t.png">USDT</option>
                                <option value="de" data-thumbnail="/assets/img/logo/ripple.png">BTC</option>
                                <option value="dk" data-thumbnail="/assets/img/logo/steem.png">USDT</option>
                                <option value="fr" data-thumbnail="/assets/img/logo/tokenbox.png">BTC</option>
                                <option value="gr" data-thumbnail="/assets/img/logo/ubex.png">USDT</option>
                              </select>
                                                    <div className="lang-select">
                                                        <button className="btn-select" value=""></button>
                                                        <div className="b second-list">
                                                            <ul id="a" className="first-list"></ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="options-row">
                                                <div className="options-label">To</div>
                                                <div className="option-value-placeholder">placeholder</div>
                                                <div className="select-holder">
                                                    <select className="poolspicker">
                                <option value="en" className="test" data-thumbnail="/assets/img/logo/ethereum.png">ETH</option>
                                <option value="au" data-thumbnail="/assets/img/logo/ethereum.png">USDT</option>
                                <option value="uk" data-thumbnail="/assets/img/logo/bitcoin.png">BTC</option>
                                <option value="cn" data-thumbnail="/assets/img/logo/logo-t.png">USDT</option>
                                <option value="de" data-thumbnail="/assets/img/logo/ripple.png">BTC</option>
                                <option value="dk" data-thumbnail="/assets/img/logo/steem.png">USDT</option>
                                <option value="fr" data-thumbnail="/assets/img/logo/tokenbox.png">BTC</option>
                                <option value="gr" data-thumbnail="/assets/img/logo/ubex.png">USDT</option>
                              </select>
                                                    <div className="lang-select">
                                                        <button className="pool-select" value=""></button>
                                                        <div className="pool-select-b pool-second-list">
                                                            <ul id="c" className="pool-first-list"></ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="submit-row">
                                                <button className="wallets__btn btn btn_border create-pol wallet-btn">
                              <span className="btn__text">Connect Wallet</span>
                            </button>
                                            </div>
                                        </div>

                                    </li>

                                    <li>
                                        <div className="liquidity-holder">
                                            <p>Connect to a wallet to view your liquidity.</p>

                                            <p>Don't see a pool you joined? <span><a href="#">Import it.</a></span></p>
                                        </div>
                                    </li>


                                </ul>


                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
      </div>
    );
  }
  
  export default swap;