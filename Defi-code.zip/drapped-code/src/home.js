
import './assets/css/bootstrap.min.css';
import './assets/css/animate.css';
import './assets/css/owl.carousel.min.css';
import './assets/css/slick.css';
import './assets/css/owl.theme.default.min.css';
import './assets/css/all.css';




function home() {
    return (
      
<div className="mainHomePage">
<div className="header-holder">
    <div className="menu-btn">
        <div className="navi-icon">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div className="custom-container">
        <div className="logo">
            <a href="index.html" className="transparent-logo"><img src="/assets/images/opt-logo4.png" alt=""/></a>
            <a href="index.html" className="white-logo"><img src="/assets/images/opt-logo4.png" alt=""/></a>
        </div>
        <div className="navigation-holder">
            <ul className="navigation">
                <li><a href="#home" className="smooth-scroll active">Home</a></li>
                <li><a href="#about-us" className="smooth-scroll">Buy Poolz </a></li>
                <li><a href="#technologies" className="smooth-scroll">Technologies</a></li>
                <li><a href="#staking" className="smooth-scroll">Stalking</a></li>

                <li><a href="/dashboard">Whitepaper</a></li>
            </ul>
        </div>
    </div>
</div>



<div id="particles-js">
    <div className="chain-container clearfix">
        <div className="banner clearfix" id="home">
            <div className="row ">



                <div className="col-md-6">
                    <div className="banner-left-detail">
                        <h1 className="heading" data-aos="fade-right" data-aos-offset="100" data-aos-easing="ease-in-sine" data-aos-duration="1500">Buy, Sell & Swap <br/> Digital Assests.</h1>
                        <p data-aos="fade-up" data-aos-anchor-placement="bottom-bottom" data-aos-duration="1900">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
                        <div className="banner-links" data-aos="zoom-in">
                            <a href="/dashboard" className="banner-first-link">Get Started</a>
                            <a href="#" className="banner-second-link"><i className="fas fa-paper-plane"></i>join our community</a>
                        </div>
                    </div>

                </div>
                <div className="col-md-6">
                    <div className="banner-right-img">
                        <img src="/assets/images/banner-right-img.png" alt=""/>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>




<div className="about-us-outer">
    <div className="chain-container clearfix">
        <div className="row" id="about-us">
            <div className="partner-logos">
                <ul className="partner-logo" data-aos="fade-up" data-aos-duration="900">
                    <li><img src="/assets/images/partner-01.png" alt=""/></li>
                    <li><img src="/assets/images/partner-02.png" alt=""/></li>
                    <li><img src="/assets/images/partner-03.png" alt=""/></li>
                    <li><img src="/assets/images/partner-04.png" alt=""/></li>
                    <li><img src="/assets/images/partner-05.png" alt=""/></li>

                </ul>
            </div>

        </div>
        <div className="row">
            <div className="col-md-6">
                <div className="about-us-left" data-aos="fade-left" data-aos-duration="900">
                    <img src="/assets/images/about-us-video.png" alt=""/>
                </div>

            </div>
            <div className="col-md-6">
                <div className="about-us-right" data-aos="fade-up" data-aos-duration="900">
                    <h3>About <span>Drapped Up</span></h3>

                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to
                        using 'Content here, making it look like readable English.Content here, making it look like readable English.</p>

                </div>
            </div>
        </div>
    </div>
</div>

<div className="our-features-outer">
    <div className="our-feature-heading" id="features" data-aos="fade-up" data-aos-duration="900">
        <h3> <span>features</span></h3>
        <div className="chain-container">
            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a look like readable English.</p>
        </div>

    </div>
    <div className="custom-container clearfix">
        <div className="row">
            <div className="col-md-4">
                <div className="feautres-detail" data-aos="fade-up" data-aos-duration="900">
                    <img src="/assets/images/vote-logo.png" alt=""/>
                    <h4>Transparancy</h4>
                    <p>Any investor got a private access to see and follow any financial and technical movements of the company. It guarantees a 100% transparency of the investment.
                    </p>
                </div>
            </div>
            <div className="col-md-4">
                <div className="feautres-detail-fd" data-aos="fade-down" data-aos-duration="900">
                    <img src="/assets/images/director-manager-icon.png" alt=""/>
                    <h4>Supervisors</h4>
                    <p>They will guarantee that the company is going to follow plans and reach their milestones. They works as a guarantee of investments and they could accept or call a vote.

                    </p>
                </div>
            </div>
            <div className="col-md-4">
                <div className="feautres-detail" data-aos="fade-up" data-aos-duration="1000">
                    <img src="/assets/images/vote-icon.png" alt=""/>
                    <h4>vote</h4>
                    <p>This feature really makes the company a DAO. Investors will have the possibility or the right to vote based on the investment made, make choices and condition the corporate performance.

                    </p>
                </div>
            </div>
            <div className="col-md-4">
                <div className="feautres-detail-fd" data-aos="fade-up" data-aos-duration="1000">
                    <img src="/assets/images/tokens-icon.png" alt=""/>
                    <h4>Tokens - Shares</h4>
                    <p>If you will partecipate in a smart contract and be part of a DAO, you can also decide in any moment to convert your token in a legal share of the company.

                    </p>
                </div>
            </div>
            <div className="col-md-4">
                <div className="feautres-detail" data-aos="fade-down" data-aos-duration="900">
                    <img src="/assets/images/custom-icon.png" alt=""/>
                    <h4>Custom Exit Strategy</h4>
                    <p>Since you are part in one of the smart contract, you can decide your own personal exit strategy putting your tokens on sell in our Decentralized Exchange.

                    </p>
                </div>
            </div>
            <div className="col-md-4">
                <div className="feautres-detail-fd" data-aos="fade-up" data-aos-duration="1000">
                    <img src="/assets/images/vote-sec-icon.png" alt=""/>
                    <h4>vote</h4>
                    <p>In accordance with the policies of each tokenized company, you can have access to exclusive rewards or personalized rights based on the criteria established by them.

                    </p>
                </div>
            </div>
        </div>
    </div>




   
    <div className="technologies-outer" id="technologies">
        <div className="chain-container clearfix">
            <div className="row">
                <div className="col-md-5">
                    <div className="technologies-left " data-aos="fade-up" data-aos-duration="1600">
                        <h3>Blockchain </h3>
                        <span>Technologies</span>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a established fact that a reader will be distracted page when looking at its layout.</p>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a established fact that a reader will be distracted page when looking at its layout.</p>
                        <div className="technologies-links">
                            <a href="#" className="technologies-btn">Poolz Mainnet<i className="fal fa-long-arrow-right"></i></a>
                        </div>

                    </div>
                </div>
                <div className="col-md-7">
                    <div className="technologies-right">
                        <div className="non-conditional-card" data-aos="fade-up" data-aos-duration="1600">
                            <img src="/assets/images/non-cond-icon.png" alt=""/>
                            <div className="tech-right-detail-holder">
                                <h4>Non Custodial</h4>
                                <p>It is a long established fact that a reader will be distracted by the readable layout. look English</p>
                            </div>


                        </div>
                        <div className="safe-secure-card" data-aos="fade-up" data-aos-duration="1600">
                            <img src="/assets/images/safe-secure-icon.png" alt=""/>
                            <div className="tech-right-detail-holder">
                                <h4>Safe & Secure
                                </h4>
                                <p>It is a long established fact that a reader will be distracted by the readable layout. look English</p>
                            </div>


                        </div>
                        <div className="non-custo-card" data-aos="fade-up" data-aos-duration="1600">
                            <img src="/assets/images/non-custodial-icon.png" alt=""/>
                            <div className="tech-right-detail-holder">
                                <h4>Non Custodial</h4>
                                <p>It is a long established fact that a reader will be distracted by the readable layout. look English</p>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div className="crypto-deb-outer" id="staking">
        <div className="chain-container clearfix">
            <div className="row">
                <div className="col-md-6">
                    <div className="crypto-left-img" data-aos="fade-up" data-aos-duration="1400">
                        <img src="/assets/images/cypto-img.jpg" alt=""/>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="crypto-right-detail" data-aos="fade-up" data-aos-duration="1400">
                        <h4>Crypto with <span>Debit Card</span></h4>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed
                            to using 'Content here, making it look like readable English.Content here, making it look like readable English.</p>
                        <div className="crypto-detail-icon">
                            <img src="/assets/images/right-arrow.png" alt=""/>
                            <span>Instant settelement to your wallet.</span>
                        </div>
                        <div className="crypto-detail-icon">
                            <img src="/assets/images/right-arrow.png" alt=""/>
                            <span>Low transaction rate of 3.5%</span>
                        </div>
                        <div className="crypto-detail-icon">
                            <img src="/assets/images/right-arrow.png" alt=""/>
                            <span>Accepts Visa and Mastercard.</span>
                        </div>


                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-md-6">
                    <div className="cultivation-detail" data-aos="fade-up" data-aos-duration="1400">
                        <h3>Cultivating <span>bleeding-edge</span></h3>

                        <div className="slidecontainer">
                            <p>Starting Amount: <span id="demo"></span></p>
                            <input type="range" min="1" max="100" value="50" className="slider" id="myRange"/>
                            <p>Starting Amount: <span id="demo"></span></p>
                            <input type="range" min="1" max="100" value="50" className="slider" id="myRange"/>
                            <p>Starting Amount: <span id="demo"></span></p>
                            <input type="range" min="1" max="100" value="50" className="slider" id="myRange"/>
                        </div>
                    </div>




                </div>
                <div className="col-md-6">
                    <div className="progress-right-img" data-aos="fade-up" data-aos-duration="1400">
                        <div className="progress-card">
                            <h5>Amount</h5>
                            <span>$90000</span>
                            <p>It is a long established fact that a </p>

                        </div>
                        <img src="/assets/images/progress-bar-right-bg.jpg" alt=""/>
                    </div>
                </div>
            </div>
        </div>
    </div>


  
    <div className="teamouter">
        <div className="chain-container clearfix">
            <div className="our-team-heading" data-aos="fade-up" data-aos-duration="1000" id="our-team">
                <span>Join our</span>
                <h3>community</h3>
            </div>
        </div>

        <div className="chain-container clearfix">
            <div className="latest-news owl-carousel owl-theme">
                <div className="item">
                    <div className="team-member" data-aos="fade-right" data-aos-duration="1000">
                        <div className="team-person clearfix">
                            <div className="member-social-link">
                                <img src="/assets/images/linkdin-icon.png" alt=""/>
                            </div>
                            <img src="/assets/images/team-member.png" alt=""/>
                        </div>

                        <h4>Waylon Dalton</h4>
                        <p>CEO & Lead Blockchain</p>
                        <p>It is a long established fact that a reader will be distracted by the readable layout. look English distracted by the readable layout. look Englishestablished fact that a reader will be distracted </p>
                    </div>
                </div>
                <div className="item">
                    <div className="team-member" data-aos="fade-right" data-aos-duration="1000">
                        <div className="team-person clearfix">
                            <div className="member-social-link">
                                <img src="/assets/images/linkdin-icon.png" alt=""/>
                            </div>
                            <img src="/assets/images/team-member.png" alt=""/>
                        </div>

                        <h4>Waylon Dalton</h4>
                        <p>CEO & Lead Blockchain</p>
                        <p>It is a long established fact that a reader will be distracted by the readable layout. look English distracted by the readable layout. look Englishestablished fact that a reader will be distracted </p>
                    </div>
                </div>
                <div className="item">
                    <div className="team-member" data-aos="fade-right" data-aos-duration="1000">
                        <div className="team-person clearfix">
                            <div className="member-social-link">
                                <img src="/assets/images/linkdin-icon.png" alt=""/>
                            </div>
                            <img src="/assets/images/team-member.png" alt=""/>
                        </div>

                        <h4>Waylon Dalton</h4>
                        <p>CEO & Lead Blockchain</p>
                        <p>It is a long established fact that a reader will be distracted by the readable layout. look English distracted by the readable layout. look Englishestablished fact that a reader will be distracted </p>
                    </div>
                </div>
                <div className="item">
                    <div className="team-member" data-aos="fade-right" data-aos-duration="1000">
                        <div className="team-person clearfix">
                            <div className="member-social-link">
                                <img src="/assets/images/linkdin-icon.png" alt=""/>
                            </div>
                            <img src="/assets/images/team-member.png" alt=""/>
                        </div>

                        <h4>Waylon Dalton</h4>
                        <p>CEO & Lead Blockchain</p>
                        <p>It is a long established fact that a reader will be distracted by the readable layout. look English distracted by the readable layout. look Englishestablished fact that a reader will be distracted </p>
                    </div>
                </div>
            </div>

        </div>

    </div>




   
    <div className="news-letter-outer">
        <div className="chain-container clearfix">
            <div className="news-letter-inner clearfix">
                <p>Let’s Keep in touch!</p>
                <ul className="footer-icon-nav">
                    <li>
                        <a href=""><img src="/assets/images/facebook-icon.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/twitter-icon.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/footer-bing-icon.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/footer-social-05.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/bitcoin-icon.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/medium-icon.png" alt=""/></a>
                    </li>
                    <li>
                        <a href=""><img src="/assets/images/send-message-icon.png" alt=""/></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div className="chain-container clearfix">
    <div className="row" id="roadmap">

        <div className="col-md-6">
            <div className="footer-left-outer" data-aos="fade-up" data-aos-duration="1400">
                <div className="footer-left-detail">
                    <a href="index.html"><img src="/assets/images/opt-logo4.png" alt=""/></a>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout as opposed to using 'Content here, content here', making it look like readable English.</p>
                    <section className="home-newsletter">

                        <div className="input-group">
                            <input type="text" className="form-control" placeholder="Enter your email"/>
                            <span className="input-group-btn">
          <button className="btn btn-theme" type="submit">Subscribe</button>
          </span>
                        </div>

                    </section>
                </div>
            </div>
        </div>
        <div className="col-md-2">
            <div className="footer-center-links" data-aos="fade-up" data-aos-duration="1400">
                <h5>Navigation</h5>
                <ul>
                    <li>
                        <a href="#">Home</a>
                    </li>
                    <li>
                        <a href="#">Buy Poolz</a>
                    </li>
                    <li>
                        <a href="#">Technologies</a>
                    </li>
                    <li>
                        <a href="#"> Stalking</a>
                    </li>
                </ul>
            </div>
        </div>
        <div className="col-md-4">
            <div className="footer-right-links" data-aos="fade-up" data-aos-duration="1400">
                <h5>Contact with us</h5>
                <p>infor@Drappedup.com</p>
                <p>support@Drappedup.com</p>
                <p>+92 311 4794 366</p>
                <p>13th Street 47 W 47th</p>
            </div>

        </div>
    </div>
</div>
<div className="footer-bottom">
    <div className="chain-container clearfix">

        <p>Copyright © 2021 Drapped Up. All rights reserved.</p>
    </div>
</div>
<div id="c-mask-right" className="c-mask"></div>
</div>


    );
  }
  
  export default home;