import './App.css';
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';

function pair() {
    return (
        <div className="page">
        <div className="sidebar">
         <div className="sidebar__head">
            <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
            <button className="sidebar__toggle">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                  <path d="M22 12H3" stroke="#11142d"></path>
                  <g stroke="#808191">
                     <path d="M22 4H13"></path>
                     <path opacity=".301" d="M22 20H13"></path>
                  </g>
                  <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
               </svg>
            </button>
            <button className="sidebar__close">
               <svg className="icon icon-close">
                 
               </svg>
            </button>
         </div>
      
         <div className="sidebar__body">
            <nav className="sidebar__nav">
            <a className="sidebar__item" href="/dashboard">
               <div className="sidebar__icon">
                  <svg className="icon icon-home">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Dashboard</div>
            </a>
            
      
            <a className="sidebar__item" href="/statistics">
          
               <div className="sidebar__icon">
                  <svg className="icon icon-chart">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Statistics</div>
            
            </a>
      
            <a className="sidebar__item active" href="/pairs">
               <div className="sidebar__icon">
                  <svg className="icon icon-document">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Pairs</div>
            </a>
            <a className="sidebar__item" href="/swap">
               <div className="sidebar__icon">
                  <svg className="icon icon-wallet">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Swap</div>
            </a>
            <a className="sidebar__item" href="/staking">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Staking</div>
            </a>
            <a className="sidebar__item" href="/promotions">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Promotions</div>
            </a>
            <a className="sidebar__item" href="/presale">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Apply For Presale</div>
            </a>
            <a className="sidebar__item" href="/activities"></a>
            </nav>
         </div>
      
         <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
        
         </svg><svg className="icon icon-theme-dark">
         
         </svg></span></span></label>
         <a className="sidebar__user" href="sign-in.html">
           <img src={"/assets/img/ava-header.png"} />
           
           </a>
         </div>
      </div>
      
      <div className="page__content">
            <div className="header header_border">
                <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
                <div className="header__group">



                    <button className="wallets__btn btn btn_border create-pol">
                  
                  <span className="btn__text">Connect Wallet</span></button>
                </div>
                <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a><button className="header__toggle"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path d="M22 12H3" stroke="#11142d"></path>
              <g stroke="#808191">
                <path d="M22 4H13"></path>
                <path opacity=".301" d="M22 20H13"></path>
              </g>
              <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
            </svg></button>
            </div>

            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">
                        <div className="pairs-search">
                            <form className="notifications__search"><input className="notifications__input" type="text" placeholder="Seach by Pool Name, Pool ID or by Token Contract Address"/>
                                <button className="notifications__start"><svg className="icon icon-search">
              
            </svg></button></form>
                        </div>

                    </div>

                </div>
                <div className="balances">

                    <div className="balances__table">
                        <div className="balances__row balances__row_head">
                            <div className="balances__cell"></div>
                            <div className="balances__cell">Name</div>
                            <div className="balances__cell">Liquidity</div>
                            <div className="balances__cell">Volume (24hrs)</div>
                            <div className="balances__cell">Volume (7d)</div>
                            <div className="balances__cell">Fees (24hrs)</div>
                            <div className="balances__cell">1 year Fees / Liquidity</div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>
                        <div className="balances__row">
                            <div className="balances__cell"><button className="favorite"></button></div>
                            <div className="balances__cell">
                                <div className="balances__company">
                                    <div className="balances__logo"><img src="/assets/img/logo/bitcoin.png"/></div>
                                    <div className="balances__text">Bitcoin</div>
                                </div>
                            </div>
                            <div className="balances__cell">BTC</div>
                            <div className="balances__cell">
                                <div className="balances__number">$49,046,886,271</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">19,266.6454898</div>

                            </div>
                            <div className="balances__cell">
                                <div className="balances__number">357,466,449,337</div>

                            </div>
                            <div className="balances__cell">
                                <div className="status positive">+2.05%</div>


                            </div>
                        </div>






                    </div>
                    <div className="balances__btns"><button className="balances__btn btn btn_blue">Load more</button></div>
                </div>
            </div>


        </div>
      </div>
    );
  }
  
  export default pair;