import logo from './logo.svg';
import './App.css';
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';




function statistics() {
  return (
    
 <div className="page">

<div className="sidebar">
   <div className="sidebar__head">
      <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
      <button className="sidebar__toggle">
         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
            <path d="M22 12H3" stroke="#11142d"></path>
            <g stroke="#808191">
               <path d="M22 4H13"></path>
               <path opacity=".301" d="M22 20H13"></path>
            </g>
            <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
         </svg>
      </button>
      <button className="sidebar__close">
         <svg className="icon icon-close">
           
         </svg>
      </button>
   </div>

   <div className="sidebar__body">
      <nav className="sidebar__nav">
      <a className="sidebar__item" href="/dashboard">
         <div className="sidebar__icon">
            <svg className="icon icon-home">
               
            </svg>
         </div>
         <div className="sidebar__text">Dashboard</div>
      </a>
      

      <a className="sidebar__item active" href="/statistics">
    
         <div className="sidebar__icon">
            <svg className="icon icon-chart">
              
            </svg>
         </div>
         <div className="sidebar__text">Statistics</div>
      
      </a>

      <a className="sidebar__item" href="/pairs">
         <div className="sidebar__icon">
            <svg className="icon icon-document">
              
            </svg>
         </div>
         <div className="sidebar__text">Pairs</div>
      </a>
      <a className="sidebar__item" href="/swap">
         <div className="sidebar__icon">
            <svg className="icon icon-wallet">
               
            </svg>
         </div>
         <div className="sidebar__text">Swap</div>
      </a>
      <a className="sidebar__item" href="/staking">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Staking</div>
      </a>
      <a className="sidebar__item" href="/promotions">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Promotions</div>
      </a>
      <a className="sidebar__item" href="/presale">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Apply For Presale</div>
      </a>
      <a className="sidebar__item" href="/activities"></a>
      </nav>
   </div>

   <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
  
   </svg><svg className="icon icon-theme-dark">
   
   </svg></span></span></label>
   <a className="sidebar__user" href="sign-in.html">
     <img src={"/assets/img/ava-header.png"} />
     
     </a>
   </div>
</div>

<div className="page__content">
            <div className="header header_border">
                <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
                <div className="header__group">



                    <button className="wallets__btn btn btn_border create-pol">
                  
                  <span className="btn__text">Connect Wallet</span></button>
                </div>
                <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a><button className="header__toggle"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path d="M22 12H3" stroke="#11142d"></path>
              <g stroke="#808191">
                <path d="M22 4H13"></path>
                <path opacity=".301" d="M22 20H13"></path>
              </g>
              <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
            </svg></button>
            </div>
            <div className="container-fluid">
                <div className="cards-outer">
                    <div className="row">
                        <div className="col-md-4">
                            <div className="total-balance-card">
                                <p>Total Balance</p>
                                <span>ETH</span>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="total-volume-card">
                                <p>Total Volume</p>
                                <span>--</span>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="total-poolz-card">
                                <p>Total Poolz</p>
                                <span>--</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <div className="activity">
                <div className="activity__container">
                    <div className="activity__stage h6 mobile-show">History</div>
                    <div className="activity__sorting">
                        <div className="activity__select tablet-show"><select className="select">
                  <option>All</option>
                  <option>Withdrawals</option>
                  <option>Deposit</option>
                  <option>Bank Withdraws</option>
                </select></div>
                        <div className="activity__tags tablet-hide"><a className="activity__link active" href="#">All</a>
                            <a className="activity__link" href="#">Withdrawals</a><a className="activity__link" href="#">Deposit</a><a className="activity__link" href="#">Bank Withdraws</a></div>
                        <div className="activity__select">
                            <div className="activity__icon"><svg className="icon icon-calendar">
                    
                  </svg></div>
                            <select className="select">
                  <option>All Time</option>
                  <option>This past week</option>
                  <option>This Past Month</option>
                  <option>This Past Year</option>
                </select>
                        </div>
                    </div>
                    <div className="activity__stage h6 mobile-hide">History</div>
                    <div className="activity__table">
                        <div className="activity__row activity__row_head">
                            <div className="activity__cell"></div>
                            <div className="activity__cell">TYPE</div>
                            <div className="activity__cell">DATE</div>
                            <div className="activity__cell">AMOUNT <span className="activity__hidden">/ DATE</span></div>
                            <div className="activity__cell">ADDRESS / TRANSACTION ID</div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/bitcoin.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-min.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/logo-t.png" alt=""/></div>
                                    <div className="activity__name">Deposited USDT</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">5342.000000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/tokenbox.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-min.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/ubex.png" alt=""/></div>
                                    <div className="activity__name">Deposited USDT</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">5342.000000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/ripple.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/bitcoin.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-min.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/logo-t.png" alt=""/></div>
                                    <div className="activity__name">Deposited USDT</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">5342.000000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/tokenbox.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-min.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/ubex.png" alt=""/></div>
                                    <div className="activity__name">Deposited USDT</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">5342.000000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                        <div className="activity__row">
                            <div className="activity__cell">
                                <div className="activity__size"><img src="/assets/img/size-max.svg" alt=""/></div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__company">
                                    <div className="activity__logo"><img src="/assets/img/logo/ripple.png" alt=""/></div>
                                    <div className="activity__name">Withdraw BTC</div>
                                </div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__date">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__price">0.12340000 USDT</div>
                                <div className="activity__date activity__hidden">Jan 17th, 2020 10:56:41</div>
                            </div>
                            <div className="activity__cell">
                                <div className="activity__address">Zja7BQo782QanKv4so</div>
                                <div className="activity__transaction">JHAEIF6374NXY3484748949</div>
                            </div>
                        </div>
                    </div>
                    <div className="prices__btns"><button className="prices__btn btn btn_blue dash-load-btn">Load more</button></div>
                </div>
                <div className="activity__sidebar">
                    <div className="activity__wrap"><button className="activity__close"><svg className="icon icon-close">
                  
                </svg></button>
                        <div className="activity__head">
                            <div className="activity__logo"><img src="/assets/img/logo/bitcoin.png" alt=""/></div>
                            <div className="activity__details">
                                <div className="activity__info">Deposit USDT</div>
                                <div className="activity__date">Jan 17th. 2020 10:56:41</div>
                            </div>
                        </div>
                        <div className="activity__line">
                            <div className="activity__money">5342.000</div>
                            <div className="activity__currency">USDT</div>
                        </div>
                        <div className="activity__code">Zja7BQo782QanKv4so</div>
                        <div className="activity__parameters">
                            <div className="activity__parameter">
                                <div className="activity__preview"><img src="/assets/img/check.svg" alt=""/></div>
                                <div className="activity__box">
                                    <div className="activity__category">Status</div>
                                    <div className="activity__status">Complete</div>
                                </div>
                            </div>
                            <div className="activity__parameter">
                                <div className="activity__preview"><img src="/assets/img/coins-1.svg" alt=""/></div>
                                <div className="activity__box">
                                    <div className="activity__category">Amount</div>
                                    <div className="activity__value">1437.000000 USDT</div>
                                </div>
                            </div>
                            <div className="activity__parameter">
                                <div className="activity__preview"><img src="/assets/img/wallet.svg" alt=""/></div>
                                <div className="activity__box">
                                    <div className="activity__category">Address </div>
                                    <div className="activity__value">Zja7BQo782QanKv4so</div>
                                </div>
                            </div>
                            <div className="activity__parameter">
                                <div className="activity__preview"><img src="/assets/img/cheque.svg" alt=""/></div>
                                <div className="activity__box">
                                    <div className="activity__category">Transaction ID</div>
                                    <div className="activity__value">JHAEIF6374NXY3484748949</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
  );
}

export default statistics ;
