
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';

function presale() {
    return (
        <div className="page">
        <div className="sidebar">
         <div className="sidebar__head">
            <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
            <button className="sidebar__toggle">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                  <path d="M22 12H3" stroke="#11142d"></path>
                  <g stroke="#808191">
                     <path d="M22 4H13"></path>
                     <path opacity=".301" d="M22 20H13"></path>
                  </g>
                  <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
               </svg>
            </button>
            <button className="sidebar__close">
               <svg className="icon icon-close">
                 
               </svg>
            </button>
         </div>
      
         <div className="sidebar__body">
            <nav className="sidebar__nav">
            <a className="sidebar__item" href="/dashboard">
               <div className="sidebar__icon">
                  <svg className="icon icon-home">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Dashboard</div>
            </a>
            
      
            <a className="sidebar__item" href="/statistics">
          
               <div className="sidebar__icon">
                  <svg className="icon icon-chart">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Statistics</div>
            
            </a>
      
            <a className="sidebar__item" href="/pairs">
               <div className="sidebar__icon">
                  <svg className="icon icon-document">
                    
                  </svg>
               </div>
               <div className="sidebar__text">Pairs</div>
            </a>
            <a className="sidebar__item" href="/swap">
               <div className="sidebar__icon">
                  <svg className="icon icon-wallet">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Swap</div>
            </a>
            <a className="sidebar__item" href="/staking">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Staking</div>
            </a>
            <a className="sidebar__item" href="/promotions">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Promotions</div>
            </a>
            <a className="sidebar__item active" href="/presale">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Apply For Presale</div>
            </a>
            <a className="sidebar__item" href="/activities"></a>
            </nav>
         </div>
      
         <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
        
         </svg><svg className="icon icon-theme-dark">
         
         </svg></span></span></label>
         <a className="sidebar__user" href="sign-in.html">
           <img src={"/assets/img/ava-header.png"} />
           
           </a>
         </div>
      </div>
      
      <div className="page__content">
            <div className="header header_border">
                <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
                <div className="header__group">



                    <button className="wallets__btn btn btn_border create-pol">
                  
                  <span className="btn__text">Connect Wallet</span></button>
                </div>
                <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a><button className="header__toggle"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path d="M22 12H3" stroke="#11142d"></path>
              <g stroke="#808191">
                <path d="M22 4H13"></path>
                <path opacity=".301" d="M22 20H13"></path>
              </g>
              <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
            </svg></button>
            </div>

            <div className="container-fluid">
                <div className="presale-page">
                    <h1>Drapped up - Token Sale Application</h1>
                    <div className="note"><span>Please note.</span> The submission fee to apply Pre-sales is 60 tokens</div>
                    <div className="presale-form">
                        <div className="row">
                            <div className="col-md-6">
                                <div className="presale-form-row">
                                    <label for="">Name - Person of Contact <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Email - Person of Contact <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Project Website <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Whitepaper link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Github link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Telegram link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Linkedin link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Twitter link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="presale-form-row">
                                    <label for="">Project summary <span>*</span></label>
                                    <textarea name="" id="" className="text-area" placeholder="Enter here..."></textarea>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Your project build on <span>*</span></label>
                                    <div className="radio-btns">
                                        <label className="label-container">Ethrium
                        <input type="radio" checked="checked" name="radio"/>
                        <span className="checkmark"></span>
                      </label>
                                        <label className="label-container">TomoChain
                        <input type="radio" name="radio"/>
                        <span className="checkmark"></span>
                      </label>
                                        <label className="label-container">Polkadot
                        <input type="radio" name="radio"/>
                        <span className="checkmark"></span>
                      </label>
                                        <label className="label-container">BSC
                        <input type="radio" name="radio"/>
                        <span className="checkmark"></span>
                      </label>
                                    </div>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Fundraising Stage <span>*</span></label>
                                    <div className="activity__select">
                                        <select className="select">
                          <option>Public sale round</option>
                          <option>This past week</option>
                          <option>This Past Month</option>
                          <option>This Past Year</option>
                        </select>
                                    </div>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">The total amount of funds you raised to date <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">How much you aim to raise? <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Token economics link <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="presale-form-row">
                                    <label for="">Company's email address <span>*</span></label>
                                    <input type="text" className="text-field" placeholder="Enter here..."/>
                                </div>
                                <div className="submit-row">
                                    <button className="wallets__btn btn btn_border create-pol wallet-btn">
                          <span className="btn__text">Submit</span>
                        </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
      </div>
    );
  }
  
  export default presale;