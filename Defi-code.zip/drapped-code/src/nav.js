import logo from './logo.svg';
import './App.css';
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';




function nav() {
  return (
    <div className="page">
  <div className="sidebar">
   <div className="sidebar__head">
      <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="img/opt-logo4.png" alt="" /></a>
      <button className="sidebar__toggle">
         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
            <path d="M22 12H3" stroke="#11142d"></path>
            <g stroke="#808191">
               <path d="M22 4H13"></path>
               <path opacity=".301" d="M22 20H13"></path>
            </g>
            <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
         </svg>
      </button>
      <button className="sidebar__close">
         <svg className="icon icon-close">
           
         </svg>
      </button>
   </div>

   <div className="sidebar__body">
      <nav className="sidebar__nav">
      <a className="sidebar__item active" href="dashboard.html">
         <div className="sidebar__icon">
            <svg className="icon icon-home">
               
            </svg>
         </div>
         <div className="sidebar__text">Dashboard</div>
      </a>
      

      <a className="sidebar__item" href="statistics.html">
    
         <div className="sidebar__icon">
            <svg className="icon icon-chart">
              
            </svg>
         </div>
         <div className="sidebar__text">Statistics</div>
      
      </a>

      <a className="sidebar__item" href="pairs.html">
         <div className="sidebar__icon">
            <svg className="icon icon-document">
              
            </svg>
         </div>
         <div className="sidebar__text">Pairs</div>
      </a>
      <a className="sidebar__item" href="swap.html">
         <div className="sidebar__icon">
            <svg className="icon icon-wallet">
               
            </svg>
         </div>
         <div className="sidebar__text">Swap</div>
      </a>
      <a className="sidebar__item" href="staking.html">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Staking</div>
      </a>
      <a className="sidebar__item" href="promotions.html">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Promotions</div>
      </a>
      <a className="sidebar__item" href="presale.html">
         <div className="sidebar__icon">
            <svg className="icon icon-discount">
               
            </svg>
         </div>
         <div className="sidebar__text">Apply For Presale</div>
      </a>
      <a className="sidebar__item" href="activities.html"></a>
      </nav>
   </div>

   <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
  
   </svg><svg className="icon icon-theme-dark">
   
   </svg></span></span></label>
   <a className="sidebar__user" href="sign-in.html"><img src="img/ava-header.png" alt="" /></a>
   </div>
</div>
</div>
  );
}

export default nav ;
