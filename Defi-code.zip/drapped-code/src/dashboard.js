import './App.css';
import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';

function dashboard() {
    return (
        <div className="page">
        <div className="sidebar">
         <div className="sidebar__head">
            <a className="sidebar__logo" href="dashboard.html"><img className="sidebar__pic sidebar__pic_light" src="/assets/img/opt-logo4.png" alt="" /><img className="sidebar__pic sidebar__pic_dark" src="/assets/img/opt-logo4.png" alt="" /></a>
            <button className="sidebar__toggle">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                  <path d="M22 12H3" stroke="#11142d"></path>
                  <g stroke="#808191">
                     <path d="M22 4H13"></path>
                     <path opacity=".301" d="M22 20H13"></path>
                  </g>
                  <path d="M7 7l-5 5 5 5" stroke="#11142d"></path>
               </svg>
            </button>
            <button className="sidebar__close">
               <svg className="icon icon-close">
                 
               </svg>
            </button>
         </div>
      
         <div className="sidebar__body">
            <nav className="sidebar__nav">
            <a className="sidebar__item active" href="/dashboard">
               <div className="sidebar__icon">
                  <svg className="icon icon-home">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Dashboard</div>
            </a>
            
      
            <a className="sidebar__item" href="/statistics">
          
               <div className="sidebar__icon">
                  <div className="icon icon-chart">
                  <img src="/assets/img/stat.png" alt=""/>
                  </div>
               </div>
               <div className="sidebar__text">Statistics</div>
            
            </a>
      
            <a className="sidebar__item" href="/pairs">
               <div className="sidebar__icon">
                  <div className="icon icon-document">
                  <img src="/assets/img/Pairs.jpg" alt=""/>
                  </div>
               </div>
               <div className="sidebar__text">Pairs</div>
            </a>
            <a className="sidebar__item" href="/swap">
               <div className="sidebar__icon">
                  <div className="icon icon-wallet">
                  <img src="/assets/img/Swap.jpg" alt=""/>
                  </div>
               </div>
               <div className="sidebar__text">Swap</div>
            </a>
            <a className="sidebar__item" href="/staking">
               <div className="sidebar__icon">
                  <div className="icon icon-discount">
                  <img src="/assets/img/Staking.jpg" alt=""/>
                  </div>
               </div>
               <div className="sidebar__text">Staking</div>
            </a>
            <a className="sidebar__item" href="/promotions">
               <div className="sidebar__icon">
                  <div className="icon icon-discount">
                  <img src="/assets/img/promotions.jpg" alt=""/>
                  </div>
               </div>
               <div className="sidebar__text">Promotions</div>
            </a>
            <a className="sidebar__item" href="/presale">
               <div className="sidebar__icon">
                  <svg className="icon icon-discount">
                     
                  </svg>
               </div>
               <div className="sidebar__text">Apply For Presale</div>
            </a>
            <a className="sidebar__item" href="/activities"></a>
            </nav>
         </div>
      
         <div className="sidebar__bottom"><label className="switch switch_theme js-switch-theme"><input className="switch__input" type="checkbox" /><span className="switch__in"><span className="switch__box"></span><span className="switch__icon"><svg className="icon icon-theme-light">
        
         </svg><svg className="icon icon-theme-dark">
         
         </svg></span></span></label>
         <a className="sidebar__user" href="sign-in.html">
           <img src={"/assets/img/ava-header.png"} />
           
           </a>
         </div>
      </div>
      
       <div className="page__content">
         <div className="header header_border">
            <a className="header__logo" href="dashboard.html"><img src="/assets/img/logo-sm.svg" alt="" /></a>
            <div className="header__group">
               <button className="wallets__btn btn btn_blue create-pol">
               <span className="btn__text">Create a Pool</span></button>
               <button className="wallets__btn btn btn_border create-pol">
               <span className="btn__text">Connect Wallet</span></button>
            </div>
            <a className="header__user" href="sign-in.html"><img src="/assets/img/ava-header.png" alt="" /></a>
            <button className="header__toggle">
            <svg width="40" viewBox="0 0 100 80" height="30" fill="#444242"><rect width="100" height="15"></rect><rect y="30" width="100" height="15"></rect><rect y="60" width="100" height="15"></rect></svg>
            </button>
         </div>
         <div className="filters-container">
            <div className="row filters">
               <div className="col-lg-4 col-xl-5">
                  <div className="activity__select plan-select">
                     <span>Choose a plan</span>
                     <select value={"Ethereum"} name="AreaId" asp-for="AreaId" className="select ">
                        <option  value="Ethereum"> Ethereum </option>
                       
                        <option value="paypal">paypal</option>
                        <option value="Ethereum">Ethereum</option>
                        
                     </select>
                  </div>
               </div>
               <div className="col-lg-4 col-xl-3">
                  <div className="choose-time">
                     <span className="label">Time Left</span>
                     <select name="department_id" id="department_id" className="select">
                        <option value="0" selected="selected">Any</option>
                        <option value="12">Any time</option>
                        <option value="2">time Select</option>
                     </select>
                  </div>
               </div>
               <div className="col-lg-4 col-xl-3">
                  <div className="choose-time">
                     <span className="label">Time Left</span>
                     <select name="department_id" id="time-left" className="select">
                        <option value="0" selected="selected">Any</option>
                        <option value="12">Any</option>
                        <option value="2">time Select</option>
                     </select>
                  </div>
               </div>
            </div>
            <div className="row">
               <form className="notifications__search">
                  <input className="notifications__input" type="text" placeholder="Seach by Pool Name, Pool ID or by Token Contract Address"/>
                  <button className="notifications__start">
                     <svg className="icon icon-search">
                       
                     </svg>
                  </button>
               </form>
            </div>
         </div>
         <div className="row">
            <div className="col-md-12">
               <div className="prices">
                  <div className="prices__container">
                     <div className="prices__table">
                        <div className="prices__row prices__row_head">
                           <div className="prices__cell">Id </div>
                           <div className="prices__cell">Pool Name</div>
                           <div className="prices__cell">Token Address</div>
                           <div className="prices__cell">Swap Ratio</div>
                           <div className="prices__cell">Token Cap</div>
                           <div className="prices__cell">Time Left</div>
                           <div className="prices__cell">JOin Pool</div>
                           <div className="prices__cell"> </div>
                        </div>
                        <a className="prices__row" href="price-details.html">
                           <div className="prices__cell">
                              <p>1</p>
                           </div>
                           <div className="prices__cell">
                              <div className="prices__company">
                                 <div className="prices__text">Bot Ocean</div>
                              </div>
                           </div>
                           <div className="prices__cell">710395...e4e23</div>
                           <div className="prices__cell">1 ETH = 0.00001 POOLZ</div>
                           <div className="prices__cell">
                              <div className="status positive">+2.05%</div>
                           </div>
                           <div className="prices__cell">Time Passed</div>
                           <div className="prices__cell"><button className="prices__btn btn btn_blue btn-lock">Locked</button></div>
                        </a>
                        <a className="prices__row" href="price-details.html">
                           <div className="prices__cell">
                              <p>2</p>
                           </div>
                           <div className="prices__cell">
                              <div className="prices__company">
                                 <div className="prices__text">Bot Ocean</div>
                              </div>
                           </div>
                           <div className="prices__cell">710395...e4e23</div>
                           <div className="prices__cell">1 ETH = 0.00001 POOLZ</div>
                           <div className="prices__cell">
                              <div className="status positive">+2.05%</div>
                           </div>
                           <div className="prices__cell">Time Passed</div>
                           <div className="prices__cell"><button className="prices__btn btn btn_blue btn-lock">Locked</button></div>
                        </a>
                        <a className="prices__row" href="price-details.html">
                           <div className="prices__cell">
                              <p>3</p>
                           </div>
                           <div className="prices__cell">
                              <div className="prices__company">
                                 <div className="prices__text">Bot Ocean</div>
                              </div>
                           </div>
                           <div className="prices__cell">710395...e4e23</div>
                           <div className="prices__cell">1 ETH = 0.00001 POOLZ</div>
                           <div className="prices__cell">
                              <div className="status positive">+2.05%</div>
                           </div>
                           <div className="prices__cell">Time Passed</div>
                           <div className="prices__cell"><button className="prices__btn btn btn_blue btn-lock">Locked</button></div>
                        </a>
                        <a className="prices__row" href="price-details.html">
                           <div className="prices__cell">
                              <p>4</p>
                           </div>
                           <div className="prices__cell">
                              <div className="prices__company">
                                 <div className="prices__text">Bot Ocean</div>
                              </div>
                           </div>
                           <div className="prices__cell">710395...e4e23</div>
                           <div className="prices__cell">1 ETH = 0.00001 POOLZ</div>
                           <div className="prices__cell">
                              <div className="status positive">+2.05%</div>
                           </div>
                           <div className="prices__cell">Time Passed</div>
                           <div className="prices__cell"><button className="prices__btn btn btn_blue btn-lock">Locked</button></div>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div className="prices__btns"><button className="prices__btn btn btn_blue dash-load-btn">Load more</button></div>
      </div>
      </div>
    );
  }
  
  export default dashboard;