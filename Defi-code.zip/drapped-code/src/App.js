import logo from './logo.svg';

import './assets/css/bootstrap.min.css';
import './assets/dash-css/all.css';

import nav from './nav';
import statistics from './statistics';
import home from './home';
import dashboard from './dashboard';
import pairs from './pair';
import swap from './swap';
import staking from './staking';
import promotions from './promotions';
import presale from './presale';
import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';


function App() {
  return (
    <Router>
    
 

<Switch>
  <Route path="/" exact component={home}/>
  <Route path="/dashboard" exact component={dashboard}/>
  <Route path="/statistics" component={statistics}/>
  <Route path="/pairs" component={pairs}/>
  <Route path="/swap" component={swap}/>
  <Route path="/staking" component={staking}/>
  <Route path="/promotions" component={promotions}/>
  <Route path="/presale" component={presale}/>
</Switch>


</Router>
  );
}



export default App;


