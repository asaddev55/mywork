
  <div class="chain-container clearfix">
<div class="row" id="roadmap" >

<div class="col-md-6">
  <div class="footer-left-outer"data-aos="fade-up" data-aos-duration="1400" >
    <div class="footer-left-detail">
      <img src="images/opt-logo4.png" alt="">
      <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout as opposed to using 'Content here, content here', making it look like readable English.</p>
      <section class="home-newsletter">

<div class="input-group">
      <input type="email" class="form-control" placeholder="Enter your email">
      <span class="input-group-btn">
      <button class="btn btn-theme" type="submit">Subscribe</button>
      </span>
      </div>

</section> 
    </div>
  </div>
</div>
<div class="col-md-2">
  <div class="footer-center-links"data-aos="fade-up" data-aos-duration="1400">
    <h5>Navigation</h5>
    <ul>
      <li>
        <a href="#">Home</a>
      </li>
      <li>
        <a href="#">Buy Poolz</a>
      </li>
      <li>
        <a href="#">Technologies</a>
      </li>
      <li>
        <a href="#"> Stalking</a>
      </li>
    </ul>
  </div>
</div>
<div class="col-md-4">
  <div class="footer-right-links" data-aos="fade-up" data-aos-duration="1400">
  <h5>Contact with us</h5>
  <p>infor@Drappedup.com</p>
  <p>support@Drappedup.com</p>
  <p>+92 311 4794 366</p>
  <p>13th Street 47 W 47th</p>
  </div>

</div>
  </div>
</div>
<div class="footer-bottom">
<div class="chain-container clearfix">

  <p>Copyright © 2021 Drapped Up. All rights reserved.</p>
</div>
</div>


<div id="c-mask-right" class="c-mask"></div>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-nav.js"></script>
<!-- <script src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script> -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- <script type='text/javascript' src='js/jquery.particleground.min.js'></script> -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<script src="js/particles.js"></script>
<script src="js/app.js"></script>
<!-- <script src="js/all.min.js"></script> -->
<script type='text/javascript' src='js/app.js'></script>
<script type='text/javascript' src='js/slick.min.js'></script>
<script type='text/javascript' src='js/owl.carousel.min.js'></script>
<script type='text/javascript' src='js/css3-animations.js'></script>
<script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
</script>
<script >$(document).ready(function() {

  var bodyEl = $('body'),
    accordionDT = $('.accordion').find('dt'),
    accordionDD = accordionDT.next('dd'),
    parentHeight = accordionDD.height(),
    childHeight = accordionDD.children('.content').outerHeight(true),
    newHeight = parentHeight > 0 ? 0 : childHeight,
    accordionPanel = $('.accordion-panel'),
    buttonsWrapper = accordionPanel.find('.buttons-wrapper'),
    openBtn = accordionPanel.find('.open-btn'),
    closeBtn = accordionPanel.find('.close-btn');

  bodyEl.on('click', function(argument) {
    var totalItems = $('.accordion').children('dt').length;
    var totalItemsOpen = $('.accordion').children('dt.is-open').length;

    if (totalItems == totalItemsOpen) {
      openBtn.addClass('hidden');
      closeBtn.removeClass('hidden');
      buttonsWrapper.addClass('is-open');
    } else {
      openBtn.removeClass('hidden');
      closeBtn.addClass('hidden');
      buttonsWrapper.removeClass('is-open');
    }
  });

  function openAll() {

    openBtn.on('click', function(argument) {

      accordionDD.each(function(argument) {
        var eachNewHeight = $(this).children('.content').outerHeight(true);
        $(this).css({
          height: eachNewHeight
        });
      });
      accordionDT.addClass('is-open');
    });
  }

  function closeAll() {

    closeBtn.on('click', function(argument) {
      accordionDD.css({
        height: 0
      });
      accordionDT.removeClass('is-open');
    });
  }

  function openCloseItem() {
    accordionDT.on('click', function() {

      var el = $(this),
        target = el.next('dd'),
        parentHeight = target.height(),
        childHeight = target.children('.content').outerHeight(true),
        newHeight = parentHeight > 0 ? 0 : childHeight;

      // animate to new height
      target.css({
        height: newHeight
      });

      // remove existing classes & add class to clicked target
      if (!el.hasClass('is-open')) {
        el.addClass('is-open');
      }

      // if we are on clicked target then remove the class
      else {
        el.removeClass('is-open');
      }
    });
  }

  openAll();
  closeAll();
  openCloseItem();
});
//# sourceURL=pen.js
</script>
<script>
  AOS.init();
</script>
<script type="text/javascript" src="js/custom.js"></script>

</body>	
</html>