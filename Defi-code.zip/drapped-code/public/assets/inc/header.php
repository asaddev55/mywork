<!doctype htm>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
		<title>Drapped Up </title>
        <link rel="icon" type="image/png" sizes="32x32" href="images/block-chain-ss-favicon.png">
        <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" media="all">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
        <link type="text/css" rel="stylesheet" href="css/animate.css" media="all">
		<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/owl.carousel.min.css" media="all">
		<link type="text/css" rel="stylesheet" href="css/slick.css.css" media="all">
		
		<link type="text/css" rel="stylesheet" href="css/owl.theme.default.min.css" media="all">
		 <!-- <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/> -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900&display=swap" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="css/all.css" media="all">
		<!-- <link type="text/css" rel="stylesheet" href="css/all.min.css"> -->
	</head>
<body id="top">

<div class="header-holder">
	<div class="menu-btn">
		<div class="navi-icon">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<div class="custom-container">
		<div class="logo">
			<a href="index.php" class="transparent-logo"><img src="images/opt-logo4.png" alt=""></a>
			<a href="index.php" class="white-logo"><img src="images/opt-logo4.png" alt=""></a>
		</div>
		<div class="navigation-holder">
			<ul class="navigation">
				<li><a href="#home" class="smooth-scroll active">Home</a></li>
				<li><a href="#about-us" class="smooth-scroll">Buy Poolz </a></li>
				<li><a href="#technologies" class="smooth-scroll">Technologies</a></li>
				<li><a href="#roadmap" class="smooth-scroll">Stalking</a></li>
				
				<li><a href="dashboard.php">Whitepaper</a></li>
			</ul>
		</div>
	</div>
</div>