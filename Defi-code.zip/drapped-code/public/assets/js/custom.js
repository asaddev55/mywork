jQuery(document).ready(function($) {

    // our work slider //
    jQuery(".latest-news").owlCarousel({
        loop: true,
        margin: 0,
        items: 3,
        dots: true,
        autoplay: false,
        responsiveClass: true,
        navText: ["<img src='../images/pre-arrow.png'>", "<img src='../images/next-arrow.png''>"],
        responsive: {
            0: {
                items: 1,
                nav: true
            },
            600: {
                items: 2,
                nav: false
            },
            1000: {
                items: 3,
                dots: true,
                nav: false,
                loop: true
            }
        }
    });
    //rang slider

    var slider = document.getElementById("myRange");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value; // Display the default slider value

    // Update the current slider value (each time you drag the slider handle)
    slider.oninput = function() {
            output.innerHTML = this.value;
        }
        //road map 
    jQuery(".owl-road").owlCarousel({
        loop: true,
        margin: 0,
        items: 5,
        nav: true,
        autoplay: true,
        responsiveClass: true,
        // navText: ["<img src='../images/pre-arrow.png'>", "<img src='../images/next-arrow.png''>"],
        responsive: {
            0: {
                loop: true,
                margin: 0,
                items: 1,
                autoplay: true,
                responsiveClass: true,
            },
            600: {
                loop: true,
                margin: 0,
                items: 2,
                autoplay: true,
                responsiveClass: true,
            },
            1000: {
                loop: true,
                dots: false,
                margin: 0,
                items: 5,
                autoplay: true,
                responsiveClass: true,
                navText: ["<img src='../images/road-map-before.png'>", "<img src='../images/road-map-after.png''>"],
            }
        }
    });

    //features slider
    jQuery(".owl-features").owlCarousel({
        loop: true,
        margin: 50,
        items: 3,
        center: true,
        autoplay: true,
        responsiveClass: true,
        navText: ["<img src='../images/pre-arrow.png'>", "<img src='../images/next-arrow.png''>"],
        responsive: {
            0: {
                loop: true,
                margin: 0,
                items: 1,
                autoplay: true,
                responsiveClass: true,
            },
            600: {
                loop: true,
                margin: 0,
                items: 2,
                autoplay: true,
                responsiveClass: true,
            },
            1000: {
                loop: true,
                dots: false,
                margin: 90,
                items: 2,
                center: true,
                nav: true,
                autoplay: true,
                responsiveClass: true,
                navText: ["<img src='../images/features-arrow.png'>", "<img src='../images/features-next.png''>"],
            }
        }
    });



    //features slider




    // =========== navigation animation ============//
    jQuery(".navi-icon").click(function() {
        jQuery(this).toggleClass('open');
        jQuery(".c-mask").fadeToggle();
        jQuery(".navigation-holder").toggleClass("open-menu");
    });
    jQuery(".c-mask").click(function() {
        jQuery(this).fadeOut();
        jQuery(".navi-icon").removeClass("open");
        jQuery(".navigation-holder").removeClass("open-menu");
    });
    jQuery("ul.navigation li a").click(function() {
        jQuery(".navi-icon").removeClass("open");
        jQuery(".navigation-holder").removeClass("open-menu");
        jQuery(".c-mask").fadeOut();
    });

    // ========== smooth scroll to section ========== //
    jQuery(".smooth-scroll").on('click', function(e) {
        e.preventDefault();
        var target = jQuery(this).attr('href');
        jQuery('html, body').animate({
            scrollTop: (jQuery(target).offset().top) - 70
        }, 1000);
    });

    jQuery(window).scroll(function() {
        var scrollDistance = jQuery(window).scrollTop() + 110;
        jQuery('.page-section').each(function(i) {
            if (jQuery(this).position().top <= scrollDistance) {
                jQuery('ul.navigation li a').removeClass('active');
                jQuery('ul.navigation li a').eq(i).addClass('active');
            }
        });
    }).scroll();


    // =========== fixed header =============== //
    var s = jQuery(".header-holder");
    var pos = s.position();
    jQuery(window).scroll(function() {
        var windowpos = jQuery(window).scrollTop();
        if (windowpos >= pos.top & windowpos >= 200) {
            s.addClass("sticky-header");
        } else {
            s.removeClass("sticky-header");
        }
    });

    // ======= portfolio sections ========//
    jQuery(".portfolio").each(function() {
        jQuery(this).hover(function() {
                jQuery(this).find(".portfolio-detail-inner").css({
                    "height": "auto",
                    "transition": "all 0.5s",
                    "top": "10px",
                    "-webkit-transform": "translateY(30px)",
                    "-ms-transform": "translateY(30px)",
                    "transform": "translateY(30px)",
                });

            },
            function() {
                jQuery(this).find(".portfolio-detail-inner").css({
                    "height": "120px",
                    "transition": "all 0.5s",
                    "top": "50%",
                    "-webkit-transform": "translateY(-50%)",
                    "-ms-transform": "translateY(-50%)",
                    "transform": "translateY(-50%)",
                });
            }
        )
    });


    //=========== particles banner ============ //
    jQuery('#particles').particleground({
        dotColor: '#696d78',
        lineColor: '#696d78'
    });

    // success message after form submit //
    var emailCount = jQuery(".emailcount").html();

    if (emailCount == 1) {
        jQuery('html, body').animate({
            scrollTop: (jQuery("#contact").offset().top) - 95
        }, 1000);
        $(".success-message").fadeIn();
    }
    particlesJS("particles-js", {
        "particles": {
            "number": {
                "value": 80,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#000"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 5
                },
                "image": {
                    "src": "img/github.svg",
                    "width": 100,
                    "height": 100
                }
            },
            "opacity": {
                "value": 9,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.22,
                    "sync": false
                }
            },
            "size": {
                "value": 5,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 40,
                    "size_min": 0.1,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": true,
                "distance": 150,
                "color": "#336699",
                "opacity": 5,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 6,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": true,
                    "mode": "grab"
                },
                "onclick": {
                    "enable": true,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 140,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 90,
                    "duration": 2,
                    "opacity": .22,
                    "speed": 8
                },
                "repulse": {
                    "distance": 200,
                    "duration": 0.4
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true
    });
    // jQuery(".navigation > li > a").click(function() {
    //     jQuery(".navigation > li > a").removeClass('active');
    //     jQuery(this).addClass('active');
    //     jQuery(".detail-submissions-toggle").slideToggle("slow");



    // })

    /* ---- stats.js config ---- */




    //feature slider



});