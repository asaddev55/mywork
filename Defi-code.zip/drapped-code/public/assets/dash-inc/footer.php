<!-- scripts-->
<script src="dash-js/lib/jquery.min.js"></script>
    <script src="dash-js/lib/svg4everybody.min.js"></script>
    <script src="dash-js/lib/owl.carousel.min.js"></script>
    <script src="dash-js/lib/jquery.nice-select.min.js"></script>
    <script src="dash-js/lib/apexcharts.min.js"></script>
    <script src="dash-js/lib/jquery.magnific-popup.min.js"></script>
    
    <script src="dash-js/charts.js"></script>
    <script src="dash-js/app.js"></script>
    <script src="dash-js/custom-select.js"></script>

    <script>
    jQuery(document).ready(function(){
       //swap page tabs
        jQuery("ul.tabs-links li").each(function(){
        var thisItem = jQuery(this).position().top;
        jQuery(this).on('click', function(){
          var index = jQuery(this).index();
          jQuery("ul.tabs-links li").removeClass("active");
          jQuery("ul.tabs-content-holder > li").removeClass("active");
          jQuery(this).addClass("active");
          jQuery("ul.tabs-content-holder > li").eq(index).addClass("active");
        });
      });



    });

    //test for getting url value from attr
// var img1 = $('.test').attr("data-thumbnail");
// console.log(img1);

//test for iterating over child elements
var langArray = [];
$('.vodiapicker option').each(function(){
  var img = $(this).attr("data-thumbnail");
  var text = this.innerText;
  var value = $(this).val();
  var item = '<li><img src="'+ img +'" alt="" value="'+value+'"/><span>'+ text +'</span></li>';
  langArray.push(item);
})

$('#a').html(langArray);

//Set the button value to the first el of the array
$('.btn-select').html(langArray[0]);
$('.btn-select').attr('value', 'en');

//change button stuff on click
$('#a li').click(function(){
   var img = $(this).find('img').attr("src");
   var value = $(this).find('img').attr('value');
   var text = this.innerText;
   var item = '<li><img src="'+ img +'" alt="" /><span>'+ text +'</span></li>';
  $('.btn-select').html(item);
  $('.btn-select').attr('value', value);
  $(".b").toggle();
  //console.log(value);
});

$(".btn-select").click(function(){
        $(".b").toggle();
    });

//check local storage for the lang
var sessionLang = localStorage.getItem('lang');
if (sessionLang){
  //find an item with value of sessionLang
  var langIndex = langArray.indexOf(sessionLang);
  $('.btn-select').html(langArray[langIndex]);
  $('.btn-select').attr('value', sessionLang);
} else {
   var langIndex = langArray.indexOf('ch');
  console.log(langIndex);
  $('.btn-select').html(langArray[langIndex]);
  //$('.btn-select').attr('value', 'en');
}




var poolsArray = [];
$('.poolspicker option').each(function(){
  var img = $(this).attr("data-thumbnail");
  var text = this.innerText;
  var value = $(this).val();
  var item = '<li><img src="'+ img +'" alt="" value="'+value+'"/><span>'+ text +'</span></li>';
  poolsArray.push(item);
})

$('#c').html(poolsArray);

//Set the button value to the first el of the array
$('.pool-select').html(poolsArray[0]);
$('.pool-select').attr('value', 'en');

//change button stuff on click
$('#c li').click(function(){
   var img = $(this).find('img').attr("src");
   var value = $(this).find('img').attr('value');
   var text = this.innerText;
   var item = '<li><img src="'+ img +'" alt="" /><span>'+ text +'</span></li>';
  $('.pool-select').html(item);
  $('.pool-select').attr('value', value);
  $(".pool-select-b").toggle();
  //console.log(value);
});

$(".pool-select").click(function(){
        $(".pool-select-b").toggle();
    });

//check local storage for the lang
var sessionLang = localStorage.getItem('lang');
if (sessionLang){
  //find an item with value of sessionLang
  var langIndex = poolsArray.indexOf(sessionLang);
  $('.pool-select').html(poolsArray[langIndex]);
  $('.pool-select').attr('value', sessionLang);
} else {
   var langIndex = poolsArray.indexOf('ch');
  console.log(langIndex);
  $('.pool-select').html(poolsArray[langIndex]);
  //$('.btn-select').attr('value', 'en');
}






   
    </script>
  </body>
</html>